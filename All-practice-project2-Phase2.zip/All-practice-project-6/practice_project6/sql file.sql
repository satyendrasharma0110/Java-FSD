create database jdbccrud;
use jdbccrud;
CREATE TABLE emp (
    emp_id int,
    emp_name  TEXT NOT NULL,
    age INT
);