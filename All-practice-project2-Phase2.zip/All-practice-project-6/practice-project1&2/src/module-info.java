/**
 * 
 */
/**
 * 
 */
module MphasisJdbcDemo {
	requires java.sql;
}