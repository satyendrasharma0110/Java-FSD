create database databaseone;


use databaseone;

CREATE TABLE emp (
    emp_id int PRIMARY KEY,
    emp_name  TEXT NOT NULL,
    salary INT
);
insert into emp values(1,'abishek',18000),(2,'sahi',19000);
insert into emp values(3,'pavan',35000),(4,'monu',36000);
