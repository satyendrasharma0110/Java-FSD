
public class AccessModifier {
	
	  public int x= 10;

	    public void publicMethod() { // Public method
	        System.out.println("This is a public method.");
	    }
	

	// PrivateAccessModifier
	    private int y = 20;

	    private void privateMethod() { // Private method
	        System.out.println("This is a private method.");
	    }


	// ProtectedAccessModifier
	    protected int z = 30; // Protected field

	    protected void protectedMethod() { // Protected method
	        System.out.println("This is a protected method.");
	    }
	

	// DefaultAccessModifier
	    int a = 40; // Default (package-private) field

	    void defaultMethod() { 
	        System.out.println("This is a default method.");
	    }

	
	    public static void main(String[] args) {
	        AccessModifier Obj = new AccessModifier();
	        
	        System.out.println("Public Variable: " + Obj.x);
	        Obj.publicMethod();
	        
	        System.out.println("Private Variable: " + Obj.y);
	        Obj.privateMethod();

	        
	        System.out.println("Protected Variable: " + Obj.z);
	        Obj.protectedMethod();

	        
	        System.out.println("Default Variable: " + Obj.a);
	        Obj.defaultMethod();
	    }
	}

