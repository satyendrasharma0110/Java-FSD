
public class MethodImplementation {
	// Method with no parameters and no return value 
		public void printMessage() {
			System.out.println("Welcome To India");
		} 
		//Method with Args and Return type 
		public int add(int a, int b) {
			return a + b;
		}
		//Method with parameter and no return type
		void addNum (int a,int b) {
			System.out.println(a+b);
		}
		//Method without parameter and with return type
		public int Numadd() {
			int b=4;
				int a=3;
				return a+b;
	}

	public static void main(String[] args) {
				MethodImplementation a1 = new MethodImplementation();
			
				System.out.println(a1.add(5, 4));

				a1.addNum(5, 4);

				a1.printMessage();

				System.out.println(a1.Numadd());

		
	  }	
	}


