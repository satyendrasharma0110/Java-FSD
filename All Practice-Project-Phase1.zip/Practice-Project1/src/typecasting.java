
public class typecasting {

	public static void main(String[] args) {
		//implicit conversion
				System.out.println("Implicit Type Casting");
				char a='B';
				System.out.println("Value of a: "+a);
				
				float b=a;
				System.out.println("Value of b: "+b);
				
				int c=a;
				System.out.println("Value of c: "+c);
				
				long d=a;
				System.out.println("Value of d: "+d);
				
				double e=a;
				System.out.println("Value of e: "+e);
				
						
				System.out.println("\n");
				
				System.out.println("Explicit Type Casting");
				//explicit conversion
				
				double x=67.51;
				int y=(int)x;
				System.out.println("Value of x: "+x);
				System.out.println("Value of y: "+y);
				


	}

}
