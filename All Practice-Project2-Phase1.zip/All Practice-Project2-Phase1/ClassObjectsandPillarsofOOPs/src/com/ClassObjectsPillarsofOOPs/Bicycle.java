package com.ClassObjectsPillarsofOOPs;

public class Bicycle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
