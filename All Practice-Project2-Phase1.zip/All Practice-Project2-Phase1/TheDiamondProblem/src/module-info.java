/**
 * 
 */
/**
 * 
 */
module TheDiamondProblem {
}